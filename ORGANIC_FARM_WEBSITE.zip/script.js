const menu=document.querySelector('#menu'),links=document.querySelector('#links');menu.onclick=()=>links.classList.toggle('open');
document.querySelectorAll('#links a').forEach(a=>a.onclick=()=>links.classList.remove('open'));
const toast=document.querySelector('#toast');document.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{toast.textContent=b.dataset.p+' availability: call or WhatsApp 6299457985';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),3000)});
